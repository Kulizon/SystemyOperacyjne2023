#define SERVER_QUE_NAME "/myQueQue"
#define MAX_MSG_SIZE 256